let carrinho = [];
let totalCarrinho = 0;

function adicionarAoCarrinho(nomeProduto, preco) {
    carrinho.push({ nome: nomeProduto, preco: preco });
    totalCarrinho += preco;
    
    atualizarCarrinho();
}

function atualizarCarrinho() {
    const itensCarrinho = document.getElementById('itensCarrinho');
    const totalElement = document.getElementById('totalCarrinho');
    
    itensCarrinho.innerHTML = ''; 

    carrinho.forEach(item => {
        const li = document.createElement('li');
        li.textContent = `${item.nome} - R$ ${item.preco.toFixed(2)}`;
        itensCarrinho.appendChild(li);
    });

    totalElement.textContent = `Total: R$ ${totalCarrinho.toFixed(2)}`;
}

let slideIndex = 0; 


function moverSlide(n) {
    const slides = document.querySelectorAll('.carrossel-container img');
    slideIndex += n;

    
    if (slideIndex < 0) {
        slideIndex = slides.length - 1;
    }

    
    if (slideIndex >= slides.length) {
        slideIndex = 0;
    }

    
    const carrosselContainer = document.querySelector('.carrossel-container');
    const newTransform = -slideIndex * 50; 
    carrosselContainer.style.transform = `translateX(${newTransform}%)`;
}
